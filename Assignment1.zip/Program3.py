#Author: Sai Santhosh Narendruni

def grading():
    try:
        try:
            score = int(input("Enter input score here:"))
        except ValueError:
            print ("Please enter only number not strings")
            return None
        if score != '' and score is not None:
            if score > 100 or score < 0:
                print("Score not in range please enter a valid score")
            else:
                if score >= 90 and score <= 100:
                    #Grade A score range greater than or equal to 90 and less than or equal to 100
                    print("A")
                elif score >= 80 and score <= 89:
                    #Grade B score range greater than or equal to 80 and less than or equal to 89
                    print("B")
                elif score >= 70 and score <= 79:
                    #Grade C score range greater than or equal to 70 and less than or equal to 79
                    print("c")
                elif score >= 60 and score <= 69:
                    #Grade D score range greater than or equal to 60 and less than or equal to 69
                    print("D")
                else:
                    print("F")
                    #Grade F score occurs below 60

        else:
            print("please enter a valid number")
    except Exception as error:
        print("Error occured {}".format(error))
#end of the block
if __name__ == "__main__":
    grading()